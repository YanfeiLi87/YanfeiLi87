#ifndef DICTIONARY_H
#define DICTIONARY_H

char** make_dictionary(char*);
void free_dictionary(char***);
int find_word(char**, char*);

#endif
